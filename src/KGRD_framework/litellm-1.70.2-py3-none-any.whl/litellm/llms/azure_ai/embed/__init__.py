from .handler import AzureAIEmbedding
